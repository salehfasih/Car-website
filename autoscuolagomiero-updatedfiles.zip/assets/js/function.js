$(document).ready(function() {

////// main slider
 $(".clients-slider").slick({
    dots:true,
    arrows: true,
    infinite: !0,
    speed: 500,
    slidesToShow: 3,
    autoplay: false,
    autoplaySpeed: 4000,
    adaptiveHeight: !0, 
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }

  ]
   
    });
////// main slider end


////// main slider
 $(".slider").slick({
    dots:true,
    arrows: true,
    infinite: !0,
    speed: 500,
    slidesToShow: 1,
    autoplay: false,
    autoplaySpeed: 4000,
    adaptiveHeight: !0, 
    });
////// main slider end



$('.toggle-menu').jPushMenu() ; 


if ($(window).width() < 760) {

$(".footer-nav h4").click(function(){
    $(this).toggleClass("open");
	var target = $(this).parent().children(".fnav");
	$(target).slideToggle();
	
  });
  
  
  $("#menu-header-nav .sub span ").click(function(){
    $(this).toggleClass("open");
	var target = $(this).parent().children(".sub-nav");
	$(target).slideToggle();
  });
 
 $(".mobile-slider").slick({
    dots:true,
    arrows: false,
 //   infinite: !0,
    speed: 500,
//    slidesToShow: 1,
    autoplay: false,
  //  autoplaySpeed: 4000,
    adaptiveHeight: !0, 
    });
  

   }

});
		
$("#menu-header-nav").clone().appendTo(".apnd-menu-device");
		


////// tabs custom (place nav and tabs anywhere separately)
$('.tabs-nav li:first-child').addClass('active');
$('.tab-content').hide();
$('.tab-content:first').show();

// Click function
$('.tabs-nav li').click(function(){
  $('.tabs-nav li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content').hide();
  
  var activeTab = $(this).find('a').attr('href');
  $(activeTab).show();
  return false;
});
////// tabs custom end




