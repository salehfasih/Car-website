jQuery(document).ready(function(e) {
    
 

	
	jQuery(".faq-main-child").click(function() {
	
      if(jQuery(this).next("div").is(":visible")){
        jQuery(this).next("div").slideUp("slow");
        jQuery(this).children().toggleClass("fa-angle-up fa-angle-down");
      } else {
        jQuery(".faq-main-child").next("div").slideUp("slow");
        jQuery(".faq-main-child i").attr("class", "fa fa-angle-down");
        jQuery(this).next("div").slideDown("slow");
        jQuery(this).children().toggleClass("fa-angle-up fa-angle-down");
      }

		
	});
	
        $("#selection").change(function() {
            location = $("#selection option:selected").val();
        });
		
 
});



